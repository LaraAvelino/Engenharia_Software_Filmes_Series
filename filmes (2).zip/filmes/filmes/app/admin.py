from django.contrib import admin
from app.models import *

admin.site.register(Genero)
admin.site.register(Episodio)
admin.site.register(Ator)
admin.site.register(Diretor)
admin.site.register(Temporada)
admin.site.register(Pais)
admin.site.register(Continente)
admin.site.register(Filme)
admin.site.register(Filme_Ator)
admin.site.register(Serie)
admin.site.register(Serie_Episodio)
