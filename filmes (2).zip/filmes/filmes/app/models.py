from django.db import models

class Genero(models.Model):
    nome = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.nome}'

class Episodio(models.Model):
    nome = models.CharField(max_length=255) 
    duracao = models.CharField(max_length=255)
    data_disponi = models.DateField

    def __str__(self):
        return f'{self.nome} {self.duracao} {self.data_disponi}'

class Ator(models.Model):
    nome = models.CharField(max_length=255) 
    site = models.CharField(max_length=255)
    insta = models.CharField(max_length=255)
    face = models.CharField(max_length=255)
    twitter = models.CharField(max_length=255)
    nacionalidade = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.nome} {self.site} {self.insta} {self.face} {self.twitter} {self.nacionalidade}'

class Diretor(models.Model):
    nome = models.CharField(max_length=255) 
    site = models.CharField(max_length=255)
    insta = models.CharField(max_length=255)
    face = models.CharField(max_length=255)
    twitter = models.CharField(max_length=255)
    nacionalidade = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.nome} {self.site} {self.insta} {self.face} {self.twitter} {self.nacionalidade}'

class Temporada(models.Model):
    periodo = models.CharField(max_length=255) 

    def __str__(self):
        return f'{self.periodo}'

class Pais(models.Model):
    nome = models.CharField(max_length=255)
    continente = models.CharField(max_length=255) 

    def __str__(self):
        return f'{self.periodo} {self.continente}'
    
class Continente(models.Model):
    nome = models.CharField(max_length=255)

    def __str__(self):
        return f'{self.nome}'

class Filme(models.Model):
    nome = models.CharField(max_length=255)
    duracao = models.CharField(max_length=255) 
    sinopse = models.CharField(max_length=255)
    site_of = models.CharField(max_length=255)
    data_lanc = models.DateField
    nota_avaliacao = models.CharField(max_length=255)
    genero = models.ForeignKey(Genero, on_delete=models.CASCADE)
    pais = models.ForeignKey(Pais, on_delete=models.CASCADE)
    diretor = models.ForeignKey(Diretor, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.nome} {self.duracao} {self.sinopse} {self.data_lac} {self.nota_avaliacao} {self.genero} {self.pais} {self.diretor} '
    
class Filme_Ator(models.Model):
    filme = models.ForeignKey(Filme, on_delete=models.CASCADE)
    ator = models.ForeignKey(Ator, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.filme} {self.ator}'
    
class Serie(models.Model):
    nome = models.CharField(max_length=255)
    duracao = models.CharField(max_length=255) 
    sinopse = models.CharField(max_length=255)
    site_of = models.CharField(max_length=255)
    data_lanc = models.DateField
    nota_avaliacao = models.CharField(max_length=255)
    genero = models.ForeignKey(Genero, on_delete=models.CASCADE)
    pais = models.ForeignKey(Pais, on_delete=models.CASCADE)
    diretor = models.ForeignKey(Diretor, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.nome} {self.duracao} {self.sinopse} {self.data_lac} {self.nota_avaliacao} {self.genero} {self.pais} {self.diretor} '

class Serie_Episodio(models.Model):
    serie = models.ForeignKey(Serie, on_delete=models.CASCADE)
    temporada = models.ForeignKey(Temporada, on_delete=models.CASCADE)
    episodio = models.ForeignKey(Episodio, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.serie} {self.temporada} {self.episodio}'