from django.shortcuts import render
from models import *

def filme(request):
     filmes = {
        'filmes':Filme.objects.all()
        }
     
     return render(request ,'filme/filme.html', filmes)


def filme_ator(request):
     filmes_atores = {
        'filmes_atores':Filme_Ator.objects.all()
        }
     
     return render(request ,'filme_ator/filme_ator.html', filmes_atores)

def genero(request):
     generos = {
        'generos':Genero.objects.all()
        }
     
     return render(request ,'genero/genero.html', generos)

def serie(request):
     series = {
        'series':Serie.objects.all()
        }
     
     return render(request ,'series/series.html', series)

def episodio(request):
     episodios = {
        'episodios':Episodio.objects.all()
        }
     
     return render(request ,'episodio/episodio.html', episodios)

def serie_episodio(request):
     series_episodios = {
        'series_episodios':Serie_Episodio.objects.all()
        }
     
     return render(request ,'serie_episodio/serie_episodio.html', series_episodios)

def ator(request):
     atores = {
        'atores':Ator.objects.all()
        }
     
     return render(request ,'ator/ator.html', atores)

def diretor(request):
     diretores = {
        'diretores':Diretor.objects.all()
        }
     
     return render(request ,'diretor/diretor.html', diretores)

def temporada(request):
     temporadas = {
        'temporadas':Temporada.objects.all()
        }
     
     return render(request ,'temporada/temporada.html', temporadas)

def pais(request):
     paises = {
        'paises':Pais.objects.all()
        }
     
     return render(request ,'pais/pais.html', paises)

def continente(request):
     continentes = {
        'continentes':Continente.objects.all()
        }
     
     return render(request ,'continente/constinente.html', continentes)