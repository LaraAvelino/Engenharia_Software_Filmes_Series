from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView
from app.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',TemplateView.as_view(template_name='index.html'), name ='index'),
    path('filme/', filme, name ='filmes'),
    path('filme_ator/', filme_ator, name ='filmes_atores'),
    path('genero/', genero, name ='generos'),
    path('serie/', serie, name ='series'),
    path('episodio/', episodio, name ='episodios'),
    path('serie_episodio/', serie_episodio, name ='series_episodios'),
    path('ator/', ator, name ='atores'),
    path('diretor/', diretor, name ='diretores'),
    path('temporada/', temporada, name ='temporadas'),
    path('pais/', pais, name ='paises'),
    path('continente/', continente, name ='continentes'),
]
